#include <iostream>
using namespace std;
class PrintServerQueue {
private:
    int* arr;
    int capacity;
    int frontIndex;
    int rearIndex;
    int count;
    void resize(int newCapacity) {
        int* newArr = new int[newCapacity];
        for (int i = 0; i < count; i++) {
            newArr[i] = arr[(frontIndex + i) % capacity];
        }
        delete[] arr;
        arr = newArr;
        capacity = newCapacity;
        frontIndex = 0;
        rearIndex = count - 1;
        cout << " Queue resized to capacity=" << capacity << endl;
    }
public:
    PrintServerQueue(int cap = 2) {
        capacity = cap;
        arr = new int[capacity];
        frontIndex = 0;
        rearIndex = -1;
        count = 0;
    }
    ~PrintServerQueue() { delete[] arr; }
    bool isEmpty() { return count == 0; }
    bool isFull() { return count == capacity; }
    void enqueue(int id) {
        if (isFull()) {
            resize(capacity * 2);
        }
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = id;
        cout << "Enqueued Print Request ID=" << id << endl;
        count++;
    }
    void dequeue() {
        if (isEmpty()) {
            cout << "Print Server Queue is empty!" << endl;
            return;
        }
        cout << "Processed & Removed Print Request ID: " << arr[frontIndex] << endl;
        frontIndex = (frontIndex + 1) % capacity;
        count--;
    }
};
int main() {
    PrintServerQueue printQ(2); 
    printQ.enqueue(101);
    printQ.enqueue(102);
    printQ.enqueue(103); 
    printQ.dequeue();
    printQ.enqueue(104);
    return 0;
}
