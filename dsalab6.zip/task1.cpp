#include <iostream>
#include <string>

using namespace std;
class CharStack {
private:
    char arr[100];
    int topIndex;
public:
    CharStack() { topIndex = -1; }
    void push(char val) { if (topIndex < 99) arr[++topIndex] = val; }
    char pop() { return (topIndex >= 0) ? arr[topIndex--] : '\0'; }
    char peek() { return (topIndex >= 0) ? arr[topIndex] : '\0'; }
    bool isEmpty() { return topIndex == -1; }
};
class StringStack {
private:
    string arr[100];
    int topIndex;
public:
    StringStack() { topIndex = -1; }
    void push(string val) { if (topIndex < 99) arr[++topIndex] = val; }
    string pop() { return (topIndex >= 0) ? arr[topIndex--] : ""; }
    bool isEmpty() { return topIndex == -1; }
};

class DoubleStack {
private:
    double arr[100];
    int topIndex;
public:
    DoubleStack() { topIndex = -1; }
    void push(double val) { if (topIndex < 99) arr[++topIndex] = val; }
    double pop() { return (topIndex >= 0) ? arr[topIndex--] : 0; }
    bool isEmpty() { return topIndex == -1; }
};

int getPrecedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

bool isOperand(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
}
string infix_to_postfix(string expr) {
    CharStack st;
    string result = "";
    for (int i = 0; i < expr.length(); i++) {
        char c = expr[i];
        if (c == ' ') continue;
        if (isOperand(c)) result += c;
        else if (c == '(') st.push('(');
        else if (c == ')') {
            while (!st.isEmpty() && st.peek() != '(') {
                result += st.peek();
                st.pop();
            }
            if (!st.isEmpty()) st.pop();
        } else {
            while (!st.isEmpty() && getPrecedence(st.peek()) >= getPrecedence(c)) {
                result += st.peek();
                st.pop();
            }
            st.push(c);
        }
    }
    while (!st.isEmpty()) {
        result += st.peek();
        st.pop();
    }
    return result;
}
string infix_to_prefix(string expr) {
    string revExpr = "";
    for (int i = expr.length() - 1; i >= 0; i--) {
        if (expr[i] == '(') revExpr += ')';
        else if (expr[i] == ')') revExpr += '(';
        else revExpr += expr[i];
    }
    CharStack st;
    string postfix = "";
    for (int i = 0; i < revExpr.length(); i++) {
        char c = revExpr[i];
        if (c == ' ') continue;
        if (isOperand(c)) postfix += c;
        else if (c == '(') st.push('(');
        else if (c == ')') {
            while (!st.isEmpty() && st.peek() != '(') {
                postfix += st.peek();
                st.pop();
            }
            if (!st.isEmpty()) st.pop();
        } else {
            while (!st.isEmpty() && getPrecedence(st.peek()) > getPrecedence(c)) {
                postfix += st.peek();
                st.pop();
            }
            st.push(c);
        }
    }
    while (!st.isEmpty()) {
        postfix += st.peek();
        st.pop();
    }
    string prefix = "";
    for (int i = postfix.length() - 1; i >= 0; i--) prefix += postfix[i];
    return prefix;
}
string postfix_to_infix(string expr) {
    StringStack st;
    for (int i = 0; i < expr.length(); i++) {
        char c = expr[i];
        if (c == ' ') continue;
        if (isOperand(c)) st.push(string(1, c));
        else {
            string op2 = st.pop();
            string op1 = st.pop();
            st.push("(" + op1 + c + op2 + ")");
        }
    }
    return st.pop();
}

double evaluate_postfix(string expr) {
    DoubleStack st;
    for (int i = 0; i < expr.length(); i++) {
        char c = expr[i];
        if (c == ' ') continue;
        if (isOperand(c)) st.push(c - '0');
        else {
            double val2 = st.pop();
            double val1 = st.pop();
            if (c == '+') st.push(val1 + val2);
            else if (c == '-') st.push(val1 - val2);
            else if (c == '*') st.push(val1 * val2);
            else if (c == '/') st.push(val1 / val2);
        }
    }
    return st.pop();
}

double evaluate_prefix(string expr) {
    DoubleStack st;
    for (int i = expr.length() - 1; i >= 0; i--) {
        char c = expr[i];
        if (c == ' ') continue;
        if (isOperand(c)) st.push(c - '0');
        else {
            double val1 = st.pop();
            double val2 = st.pop();
            if (c == '+') st.push(val1 + val2);
            else if (c == '-') st.push(val1 - val2);
            else if (c == '*') st.push(val1 * val2);
            else if (c == '/') st.push(val1 / val2);
        }
    }
    return st.pop();
}

int main() {
    string infix;
    string eval;
    cout<<"Enter the INFIX=";
    cin>>infix;
    cout<<"Enter the Expression=";
    cin>>eval;
    cout << "Infix=" << infix << endl;
    cout << "Postfix=" << infix_to_postfix(infix) << endl;
    cout << "Prefix=" << infix_to_prefix(infix) << endl;
    cout << "Evaluate Postfix" << evaluate_postfix(eval) << endl;
    return 0;
}
