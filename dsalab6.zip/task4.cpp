#include <iostream>
using namespace std;

class WaitingRoomQueue {
private:
    int arr[100];
    int frontIndex;
    int rearIndex;
    int nextId;

public:
    WaitingRoomQueue() {
        frontIndex = 0;
        rearIndex = -1;
        nextId = 1; 
    }

    void RegisterPatient() {
        if (rearIndex < 99) {
            rearIndex++;
            arr[rearIndex] = nextId;
            cout << "Patient registered successfully. Assigned ID: " << nextId << endl;
            nextId++;
        } else {
            cout << "Waiting room is full!" << endl;
        }
    }

    void ServePatient() {
        if (frontIndex > rearIndex) {
            cout << "No patients waiting to be served." << endl;
        } else {
            cout << "Now serving Patient ID: " << arr[frontIndex] << endl;
            frontIndex++;
        }
    }

    void CancelAll() {
        frontIndex = 0;
        rearIndex = -1;
        cout << "All appointments cancelled for doctor's lunch!" << endl;
    }

    bool CanDoctorGoHome() {
        return frontIndex > rearIndex;
    }

    void ShowAllPatient() {
        if (frontIndex > rearIndex) {
            cout << "No patients currently waiting in the room." << endl;
            return;
        }
        cout << "Waiting Patients IDs (Sorted order): ";
        for (int i = frontIndex; i <= rearIndex; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    WaitingRoomQueue erQueue;
    erQueue.RegisterPatient();
    erQueue.RegisterPatient();
    erQueue.RegisterPatient();
    erQueue.ShowAllPatient();
    erQueue.ServePatient();
    erQueue.ShowAllPatient();

    cout << "Can I [Doctor] go home? [I wanna go]: " << (erQueue.CanDoctorGoHome() ? "Yes" : "No") << endl;
    erQueue.CancelAll();
    cout << "Can doctor go home now? [Please mujhe chor do]: " << (erQueue.CanDoctorGoHome() ? "Yes" : "No") << endl;
    
    return 0;
}
