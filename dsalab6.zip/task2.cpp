#include <iostream>
#include <string>

using namespace std;
class CharStack {
private:
    char arr[100];
    int topIndex;
public:
    CharStack() { topIndex = -1; }
    void push(char val) { if (topIndex < 99) arr[++topIndex] = val; }
    char pop() { return (topIndex >= 0) ? arr[topIndex--] : '\0'; }
    bool isEmpty() { return topIndex == -1; }
};
bool isValidBrackets(string s) {
    CharStack st;
    for (int i = 0; i < s.length(); i++) {
        char c = s[i];
        if (c == '(' || c == '{' || c == '[') {
            st.push(c);
        } else if (c == ')' || c == '}' || c == ']') {
            if (st.isEmpty()) return false;
            char top = st.pop();
            if (c == ')' && top != '(') return false;
            if (c == '}' && top != '{') return false;
            if (c == ']' && top != '[') return false;
        }
    }
    return st.isEmpty();
}
int main() {
    string test1 = "{[()]}";
    string test2 = "{[(])}";
    cout << "Is '" << test1 << "' valid? " << (isValidBrackets(test1) ? "Yes" : "No") << endl;
    cout << "Is '" << test2 << "' valid? " << (isValidBrackets(test2) ? "Yes" : "No") << endl;
    return 0;
}
